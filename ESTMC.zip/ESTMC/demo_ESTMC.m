
clear;
clc

folder_now = pwd;
addpath([folder_now, '\funs']);
addpath([folder_now, '\dataset']);
dataname=["NGs"];

%% ==================== Load Datatset and Normalization ===================
for it_name = 1:length(dataname)
    load(strcat('dataset/',dataname(it_name),'.mat'));
    
    gt = truelabel{1};
    cls_num=length(unique(gt));
    X=data';
    nV = length(X);
    
    for v=1:nV
        [X{v}]=NormalizeData(X{v});
    end
    
    %% ========================== Parameters Setting ==========================
    result=[];
    num = 0;
    max_val=0;
    record_num = 0;
    ii=0;
    anchor=[cls_num,2*cls_num,3*cls_num,4*cls_num,5*cls_num];
    
    rank_fun = 4; % 1:Geman function,2:Lapace function, 3:l_delta function , 4:our ETR, 5:TNN
    rank_fun_name=["Geman","Lapace","l_delta","ETR","TNN"];
    
    %% ============================ Optimization ==============================
    if rank_fun ==5 %TNN
        for i_lammbda = -4:1:-1
                for i_anchor = 1:1
                    lammbda = 10^(i_lammbda);
                    delta =0;
                    anc = anchor(i_anchor);
                    ii=ii+1;
                    tic;
                    [y,FF,Z,B,converge_Z,converge_Z_G] = ESTMC(X,cls_num,delta,lammbda,anc,rank_fun);
                    time = toc;
                    [result(ii,:),res]=  ClusteringMeasure(gt, y);
                    if result(ii,1) > max_val
                        max_val = result(ii,1);
                        record = [lammbda,delta,anc,time];
                        record_result = result(ii,:);
                        record_c ={FF,Z,B,converge_Z,converge_Z_G};
                        record_time = time;
                    end
            end
        end
        disp('The best result of '+dataname(it_name)+', rank function:'+rank_fun_name(rank_fun))
        record_result
        save('.\result_ESTMC\result_ESTMC_'+rank_fun_name(rank_fun)+'_'+dataname(it_name),'result','record','max_val','record_result','time','record_c')
    else
        for i_lammbda = -4:1:-1
            for i_delta = -2:1:0
                for i_anchor = 1:1
                    lammbda = 10^(i_lammbda);
                    delta=10^(i_delta);
                    anc = anchor(i_anchor);
                    ii=ii+1;
                    tic;
                    [y,FF,Z,B,converge_Z,converge_Z_G] = ESTMC(X,cls_num,delta,lammbda,anc,rank_fun);
                    time = toc;
                    [result(ii,:),res]=  ClusteringMeasure(gt, y);
                    if result(ii,1) > max_val
                        max_val = result(ii,1);
                        record = [lammbda,delta,anc,time];
                        record_result = result(ii,:);
                        record_c ={FF,Z,B,converge_Z,converge_Z_G};
                        record_time = time;
                    end
                end
            end
        end
        disp('The best result of '+dataname(it_name)+', rank function:'+rank_fun_name(rank_fun))
        record_result
       save('.\result_ESTMC\result_ESTMC_'+rank_fun_name(rank_fun)+'_'+dataname(it_name),'result','record','max_val','record_result','time','record_c')
    end
end


